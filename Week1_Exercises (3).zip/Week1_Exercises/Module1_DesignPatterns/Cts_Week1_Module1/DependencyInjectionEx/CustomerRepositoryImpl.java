package module1_11;

public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(String id) {
        // Simulate fetching a customer from a database
        return new Customer(id, "John Doe");
    }
}
