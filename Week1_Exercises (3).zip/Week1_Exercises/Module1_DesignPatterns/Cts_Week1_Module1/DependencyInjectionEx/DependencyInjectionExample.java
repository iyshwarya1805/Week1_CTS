package module1_11;

public class DependencyInjectionExample {
    public static void main(String[] args) {
        // Create an instance of the repository implementation
        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        // Inject the repository instance into the service using constructor injection
        CustomerService customerService = new CustomerService(customerRepository);

        // Use the service to find a customer
        Customer customer = customerService.findCustomerById("123");

        // Display the customer details
        System.out.println("Customer ID: " + customer.getId());
        System.out.println("Customer Name: " + customer.getName());
    }
}

