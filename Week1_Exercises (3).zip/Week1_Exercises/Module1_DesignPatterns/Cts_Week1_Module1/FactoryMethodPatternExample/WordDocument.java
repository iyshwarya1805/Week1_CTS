package FactoryMethodPatternExample;

public  class WordDocument implements Document {
	@Override
	public void open()
	{
		System.out.println("Word doc is opening");
	}
	@Override
	public void save()
	{
		System.out.println("saving the Word doc ");
	}
	@Override
	public void close()
	{
		System.out.println("closing the word doc");
	}
}
