package module1_10;

public class MVCPatternExample {
    public static void main(String[] args) {
        // Fetch student record based on their ID from the database
        Student model = retrieveStudentFromDatabase();

        // Create a view to display student details on the console
        StudentView view = new StudentView();

        // Create a controller
        StudentController controller = new StudentController(model, view);

        // Display initial student details
        controller.updateView();

        // Update student details
        controller.setStudentName("Iysh");
        controller.setStudentGrade("A");

        // Display updated student details
        controller.updateView();
    }

    private static Student retrieveStudentFromDatabase() {
        return new Student("Iysh", "123", "B");
    }
}

