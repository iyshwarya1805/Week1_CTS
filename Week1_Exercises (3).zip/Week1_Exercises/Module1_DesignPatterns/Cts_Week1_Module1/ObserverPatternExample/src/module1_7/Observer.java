package module1_7;

public interface Observer {

	void update(double stockPrice);
}
