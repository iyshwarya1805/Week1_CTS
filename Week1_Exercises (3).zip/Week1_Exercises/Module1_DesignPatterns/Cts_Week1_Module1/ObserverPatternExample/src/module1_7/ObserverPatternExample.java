package module1_7;


public class ObserverPatternExample {
 public static void main(String[] args) {
     StockMarket stockMarket = new StockMarket();

     Observer mobileApp = new MobileApp("MobileApp1");
     Observer webApp = new WebApp("WebApp1");

     stockMarket.registerObserver(mobileApp);
     stockMarket.registerObserver(webApp);

     stockMarket.setStockPrice(1087.00);
     System.out.println("");

     stockMarket.setStockPrice(1878.50);
     System.out.println("");

     stockMarket.deregisterObserver(mobileApp);

     stockMarket.setStockPrice(1220.00);
 }
}

