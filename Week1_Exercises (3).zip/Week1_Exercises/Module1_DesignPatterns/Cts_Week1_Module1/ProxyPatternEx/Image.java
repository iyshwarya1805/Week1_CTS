package module1;

public interface Image {
	void display();
}
