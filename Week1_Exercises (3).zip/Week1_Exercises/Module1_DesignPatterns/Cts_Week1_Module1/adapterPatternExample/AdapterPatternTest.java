package adapterPatternExample;

public class AdapterPatternTest {
    public static void main(String[] args) {
        // Using PaymentGatewayA through its adapter
        PaymentProcessor processorA = new PaymentGatewayAAdapter(new PaymentGatewayA());
        processorA.processPayment(100.0);

        // Using PaymentGatewayB through its adapter
        PaymentProcessor processorB = new PaymentGatewayBAdapter(new PaymentGatewayB());
        processorB.processPayment(200.0);
    }
}