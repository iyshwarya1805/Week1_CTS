package adapterPatternExample;



 //for PaymentGatewayA
public class PaymentGatewayA {
 public void makePayment(String account, double amount) {
     System.out.println("Processing payment of $" + amount + " using PaymentGatewayA for account " + account);
 }


	
}



