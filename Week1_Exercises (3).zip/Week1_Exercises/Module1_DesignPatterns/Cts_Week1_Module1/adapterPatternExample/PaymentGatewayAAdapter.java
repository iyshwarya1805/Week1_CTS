package adapterPatternExample;
	// Adapter for PaymentGatewayA
	public class PaymentGatewayAAdapter implements PaymentProcessor {
	    private PaymentGatewayA paymentGatewayA;
	    
	    public PaymentGatewayAAdapter(PaymentGatewayA paymentGatewayA) {
	        this.paymentGatewayA = paymentGatewayA;
	    }

	    @Override
	    public void processPayment(double amount) {
	        // Call the specific method of PaymentGatewayA
	        paymentGatewayA.makePayment("DefaultAccount", amount);
	    }
	}

	

