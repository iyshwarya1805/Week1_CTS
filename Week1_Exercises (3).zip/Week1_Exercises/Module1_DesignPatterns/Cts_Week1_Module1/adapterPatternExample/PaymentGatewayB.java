package adapterPatternExample;
//for PaymentGatewayB
public class PaymentGatewayB {
	
	 public void payWithCard(String cardNumber, double amount) {
	     System.out.println("Processing payment of $" + amount + " using PaymentGatewayB with card " + cardNumber);
	 }

}
