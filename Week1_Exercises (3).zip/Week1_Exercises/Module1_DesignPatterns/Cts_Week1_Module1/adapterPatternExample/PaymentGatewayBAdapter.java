package adapterPatternExample;

//Adapter for PaymentGatewayB
	public class PaymentGatewayBAdapter implements PaymentProcessor {
	    private PaymentGatewayB paymentGatewayB;
	    
	    public PaymentGatewayBAdapter(PaymentGatewayB paymentGatewayB) {
	        this.paymentGatewayB = paymentGatewayB;
	    }

	    @Override
	    public void processPayment(double amount) {
	        // Call the specific method of PaymentGatewayB
	        paymentGatewayB.payWithCard("DefaultCardNumber" , amount);
	    }
	}
