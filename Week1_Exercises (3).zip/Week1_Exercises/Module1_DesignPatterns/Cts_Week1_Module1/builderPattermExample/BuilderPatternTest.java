package builderPattermExample;

public class BuilderPatternTest {
    public static void main(String[] args) {
        
        Computer basicComputer = new Computer.Builder("Intel i5", "8GB", "500GB SSD")
                .build();
        System.out.println("Basic Computer: " + basicComputer);

       
        Computer advancedComputer = new Computer.Builder("Intel i7", "16GB", "1TB SSD")
                .setGraphicsCard(true)      
                .setBluetooth(true)         
                .build();
        System.out.println("Advanced Computer: " + advancedComputer);

        
        Computer gamingComputer = new Computer.Builder("AMD Ryzen 9", "32GB", "2TB SSD")
                .setGraphicsCard(true)   
                .build();
        System.out.println("Gaming Computer: " + gamingComputer);
    }
}
