package builderPattermExample;

public class Computer {
    private final String CPU;
    private final String RAM;
    private final String storage;
    private final boolean isGraphicsCardIncluded;
    private final boolean isBluetoothIncluded;

    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.isGraphicsCardIncluded = builder.isGraphicsCardIncluded;
        this.isBluetoothIncluded = builder.isBluetoothIncluded;
    }

    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + ", Storage=" + storage
                + ", GraphicsCardIncluded=" + isGraphicsCardIncluded
                + ", BluetoothIncluded=" + isBluetoothIncluded + "]";
    }

    public static class Builder {
        private final String CPU;
        private final String RAM;
        private final String storage;
        private boolean isGraphicsCardIncluded = false;
        private boolean isBluetoothIncluded = false;

        public Builder(String CPU, String RAM, String storage) {
            this.CPU = CPU;
            this.RAM = RAM;
            this.storage = storage;
        }

        public Builder setGraphicsCard(boolean isGraphicsCardIncluded) {
            this.isGraphicsCardIncluded = isGraphicsCardIncluded;
            return this;
        }

        public Builder setBluetooth(boolean isBluetoothIncluded) {
            this.isBluetoothIncluded = isBluetoothIncluded;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }
}
