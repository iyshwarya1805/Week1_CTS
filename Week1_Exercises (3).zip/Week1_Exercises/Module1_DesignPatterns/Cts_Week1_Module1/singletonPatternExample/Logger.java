package singletonPatternExample;

public class Logger {
	private static Logger instance;

	private Logger() {
		super();
	}
	public static Logger getInstance()
	{
		if(instance==null)
		{
			instance=new Logger();
		}
		return instance;
	}
	public void display(String message)
	{
		System.out.println(message);
	}
	
}
