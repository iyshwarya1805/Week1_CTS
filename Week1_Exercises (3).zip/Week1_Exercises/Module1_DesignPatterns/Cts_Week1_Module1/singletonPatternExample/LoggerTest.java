package singletonPatternExample;

public class LoggerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Logger l1=Logger.getInstance();
		Logger l2=Logger.getInstance();
		if(l1==l2)
		{
			System.out.println("SingleInstance is created!Singleton is followed by Logger");
		}
		l1.display("log message");
		l2.display("another log msg");
			}

}
