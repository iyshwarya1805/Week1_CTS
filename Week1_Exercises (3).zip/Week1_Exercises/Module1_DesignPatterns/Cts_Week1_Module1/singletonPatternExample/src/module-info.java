/**
 * 
 */
/**
 * 
 */
module singletonPatternExample {
}