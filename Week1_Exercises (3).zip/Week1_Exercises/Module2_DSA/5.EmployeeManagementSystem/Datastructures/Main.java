package Datastructures;

public class Main {
    public static void main(String[] args) {
        // Create an EmployeeManagementSystem instance with a capacity of 5
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        // Add employees
        ems.addEmployee(new Employee(1, "Alice Johnson", "Developer", 60000));
        ems.addEmployee(new Employee(2, "Bob Smith", "Manager", 75000));
        ems.addEmployee(new Employee(3, "Charlie Brown", "Analyst", 55000));

        // Traverse and print all employees
        System.out.println("All Employees:");
        ems.traverseEmployees();
        System.out.println();

        // Search for an employee by ID
        Employee searchedEmployee = ems.searchEmployee(2);
        System.out.println("Search Result for Employee ID 2:");
        System.out.println(searchedEmployee != null ? searchedEmployee : "Employee not found.");
        System.out.println();

        // Delete an employee by ID
        ems.deleteEmployee(2);

        // Traverse and print all employees after deletion
        System.out.println("All Employees After Deletion:");
        ems.traverseEmployees();
    }
}
