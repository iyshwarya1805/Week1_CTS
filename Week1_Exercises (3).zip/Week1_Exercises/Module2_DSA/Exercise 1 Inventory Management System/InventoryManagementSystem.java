package com.panimalar.cts.dsa;

import java.util.HashMap;
import java.util.Map;

public class InventoryManagementSystem {
    private Map<Integer, Product> inventory;

    public InventoryManagementSystem() {
        this.inventory = new HashMap<>();
    }

    public void addProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            System.out.println("Product with ID " + product.getProductId() + " already exists.");
        } else {
            inventory.put(product.getProductId(), product);
            System.out.println("Product " + product.getProductName() + " added.");
        }
    }

    public void updateProduct(int productId, String productName, Integer quantity, Double price) {
        if (inventory.containsKey(productId)) {
            Product product = inventory.get(productId);
            if (productName != null) {
                product.setProductName(productName);
            }
            if (quantity != null) {
                product.setQuantity(quantity);
            }
            if (price != null) {
                product.setPrice(price);
            }
            System.out.println("Product " + productId + " updated.");
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }

    public void deleteProduct(int productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
            System.out.println("Product " + productId + " deleted.");
        } else {
            System.out.println("Product with ID " + productId + " does not exist.");
        }
    }

    public void displayInventory() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        InventoryManagementSystem inventorySystem = new InventoryManagementSystem();

        // Adding products
        Product product1 = new Product(1, "Laptop", 50, 1000.0);
        Product product2 = new Product(2, "Smartphone", 100, 500.0);
        Product product3 = new Product(3, "Tablet", 30, 300.0);

        inventorySystem.addProduct(product1);
        inventorySystem.addProduct(product2);
        inventorySystem.addProduct(product3);

        // Display inventory
        System.out.println("\nInventory after adding products:");
        inventorySystem.displayInventory();

        // Updating a product
        inventorySystem.updateProduct(1, null, 45, null);

        // Display inventory after update
        System.out.println("\nInventory after updating product 1:");
        inventorySystem.displayInventory();

        // Deleting a product
        inventorySystem.deleteProduct(2);

        // Display inventory after deletion
        System.out.println("\nInventory after deleting product 2:");
        inventorySystem.displayInventory();
    }
}
