package com.panimalar.cts.dsa6;

import java.util.ArrayList;
import java.util.List;

public class Library {
    private List<Book> books;

    public Library() {
        books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public List<Book> getBooks() {
        return books;
    }

    // Linear search to find books by title
    public List<Book> linearSearchByTitle(String title) {
        List<Book> foundBooks = new ArrayList<>();
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                foundBooks.add(book);
            }
        }
        return foundBooks;
    }

    // Binary search to find books by title (assuming the list is sorted)
    public List<Book> binarySearchByTitle(String title) {
        List<Book> foundBooks = new ArrayList<>();
        int left = 0;
        int right = books.size() - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int compareResult = books.get(mid).getTitle().compareToIgnoreCase(title);
            if (compareResult == 0) {
                // If we found a match, look around mid for other matches
                int temp = mid;
                while (temp >= left && books.get(temp).getTitle().equalsIgnoreCase(title)) {
                    foundBooks.add(books.get(temp));
                    temp--;
                }
                temp = mid + 1;
                while (temp <= right && books.get(temp).getTitle().equalsIgnoreCase(title)) {
                    foundBooks.add(books.get(temp));
                    temp++;
                }
                break;
            } else if (compareResult < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return foundBooks;
    }
}
