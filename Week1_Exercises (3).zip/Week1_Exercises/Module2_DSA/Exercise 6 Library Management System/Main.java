package com.panimalar.cts.dsa6;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        library.addBook(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book(2, "1984", "George Orwell"));
        library.addBook(new Book(3, "To Kill a Mockingbird", "Harper Lee"));
        library.addBook(new Book(4, "The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book(5, "Moby Dick", "Herman Melville"));

        // Linear Search
        System.out.println("Linear Search:");
        List<Book> foundBooksLinear = library.linearSearchByTitle("The Great Gatsby");
        for (Book book : foundBooksLinear) {
            System.out.println(book);
        }

        // Binary Search (make sure the list is sorted by title)
        library.getBooks().sort((b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));
        System.out.println("\nBinary Search:");
        List<Book> foundBooksBinary = library.binarySearchByTitle("The Great Gatsby");
        for (Book book : foundBooksBinary) {
            System.out.println(book);
        }
    }
}
