package Forecating;

import java.util.HashMap;
import java.util.Map;

public class FinancialForecasting2 {

    // Method to calculate future value recursively with memoization
    public static double calculateFutureValue(double presentValue, double growthRate, int periods, Map<Integer, Double> memo) {
        // Base case: If no periods left, return the present value
        if (periods == 0) {
            return presentValue;
        }

        // Check if the value is already computed
        if (memo.containsKey(periods)) {
            return memo.get(periods);
        }

        // Recursive case: Calculate the future value for the next period
        double futureValue = calculateFutureValue(presentValue * (1 + growthRate), growthRate, periods - 1, memo);
        memo.put(periods, futureValue); // Store the result in the memo map
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1000.0;
        double growthRate = 0.05; // 5% growth rate
        int periods = 10; // 10 periods
        Map<Integer, Double> memo = new HashMap<>();

        double futureValue = calculateFutureValue(presentValue, growthRate, periods, memo);
        System.out.println("Future Value: " + futureValue);
    }
}

